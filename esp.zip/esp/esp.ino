#include <WiFi.h>
#include <HTTPClient.h>
#include <ArduinoJson.h>

// CONFIGURATION
const char* WIFI_SSID = "SLT-4G_1F3ABD";
const char* WIFI_PASS = "6CFB5717";

const char* FIREBASE_DB_URL = "https://pcb-fault-detection-system-default-rtdb.asia-southeast1.firebasedatabase.app/";

// Hardware Pin Definitions
const int RED_LED_PIN = 25;    // lights up when a fault is confirmed
const int GREEN_LED_PIN = 26;  // lights up when the system is normal
const int BUZZER_PIN = 27;     // sounds when a fault is confirmed

// Polling Interval Config 
const unsigned long POLL_INTERVAL = 500;
unsigned long lastPollTime = 0;

void setup() {
  Serial.begin(115200);

  pinMode(RED_LED_PIN, OUTPUT);
  pinMode(GREEN_LED_PIN, OUTPUT);
  pinMode(BUZZER_PIN, OUTPUT);

  // Initial State: System Normal
  digitalWrite(RED_LED_PIN, LOW);
  digitalWrite(GREEN_LED_PIN, HIGH);
  digitalWrite(BUZZER_PIN, LOW);

  // Connect to WiFi
  WiFi.begin(WIFI_SSID, WIFI_PASS);
  Serial.print("[WiFi] Connecting to network...");
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  Serial.println("\n[WiFi] Connected successfully!");
  Serial.print("[WiFi] IP Address: ");
  Serial.println(WiFi.localIP());
}

void loop() {
  unsigned long currentMillis = millis();

  if (currentMillis - lastPollTime >= POLL_INTERVAL) {
    lastPollTime = currentMillis;

    if (WiFi.status() == WL_CONNECTED) {
      checkFaultStatus();
    } else {
      Serial.println("[WiFi] Lost Connection. Reconnecting...");
      WiFi.reconnect();
    }
  }
}

void checkFaultStatus() {
  HTTPClient http;
  String url = String(FIREBASE_DB_URL) + "/status.json";

  http.begin(url);
  int httpCode = http.GET();

  if (httpCode == HTTP_CODE_OK) {
    String payload = http.getString();

    // Parse JSON Response
    StaticJsonDocument<512> doc;
    DeserializationError error = deserializeJson(doc, payload);

    if (!error) {
      bool isFault = doc["fault"] | false;
      const char* defectName = doc["name"] | "None";

      if (isFault) {
        // DEFECT DETECTED: Red LED + Buzzer ON, Green LED OFF
        digitalWrite(RED_LED_PIN, HIGH);
        digitalWrite(GREEN_LED_PIN, LOW);
        digitalWrite(BUZZER_PIN, HIGH);
        Serial.printf("[ALERT] Fault Active! Type: %s\n", defectName);
      } else {
        // SYSTEM NORMAL: Green LED ON, Red LED + Buzzer OFF
        digitalWrite(RED_LED_PIN, LOW);
        digitalWrite(GREEN_LED_PIN, HIGH);
        digitalWrite(BUZZER_PIN, LOW);
        Serial.println("[STATUS] System Normal (OK)");
      }
    } else {
      Serial.print("[JSON] Parsing failed: ");
      Serial.println(error.c_str());
    }
  } else {
    Serial.printf("[HTTP] GET failed, error code: %d\n", httpCode);
  }

  http.end();
}
